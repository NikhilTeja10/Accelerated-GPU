from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

class GoogleSheetsHandler:
    def __init__(self, credentials_file, sheet_id):
        # Authenticate using service account credentials
        self.credentials = Credentials.from_service_account_file(credentials_file)
        self.sheet_id = sheet_id
        self.service = build('sheets', 'v4', credentials=self.credentials)

    def get_tasks(self, range_name='Sheet1!A1:C100'):
        """Fetch tasks from columns A, B, and C for up to 100 rows in Google Sheets."""
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=self.sheet_id,
                range=range_name
            ).execute()
            values = result.get('values', [])
            if values:
                # Format data row by row (filling missing columns with an empty string)
                formatted_tasks = [
                    " | ".join(row + [''] * (3 - len(row)))  # Ensure each row has 3 columns (A, B, C)
                    for row in values
                ]
                return formatted_tasks
            return []
        except Exception as e:
            print(f"Error reading from Google Sheets: {e}")
            return []