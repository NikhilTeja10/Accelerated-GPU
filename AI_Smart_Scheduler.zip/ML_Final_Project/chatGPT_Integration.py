import openai

class ChatGPTHandler:
    def __init__(self, api_key):
         openai.api_key = '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'

    def get_response(self, prompt):
        """Send a prompt to ChatGPT and get a response."""
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "system", "content": "You are a helpful assistant."},
                          {"role": "user", "content": prompt}]
            )
            return response['choices'][0]['message']['content']
        except Exception as e:
            print(f"Error with ChatGPT API: {e}")
            return "Sorry, I couldn't process your request."
