from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
import ast

class GoogleSheetsHandler:
    def __init__(self, credentials_file, sheet_id):
        # Authenticate using service account credentials
        self.credentials = Credentials.from_service_account_file(credentials_file)
        self.sheet_id = sheet_id
        self.service = build('sheets', 'v4', credentials=self.credentials)

    def evaluate_expression(self, expression):
        """Safely evaluate mathematical expressions."""
        try:
            # Evaluate only if it's a valid Python expression
            return ast.literal_eval(expression)
        except (ValueError, SyntaxError):
            # If not evaluatable, return None
            return None

    def get_tasks(self, range_name='Sheet1!A1:C100'):
        """Fetch tasks and evaluate equations from columns A, B, and C for up to 100 rows."""
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=self.sheet_id,
                range=range_name
            ).execute()
            values = result.get('values', [])
            
            tasks_and_results = []
            for row in values:
                # Process each cell in the row
                processed_row = []
                for cell in row:
                    # Try evaluating the cell as an expression
                    result = self.evaluate_expression(cell)
                    if result is not None:  # If evaluatable, append the result
                        processed_row.append(str(result))
                    else:  # Otherwise, append the raw cell data
                        processed_row.append(cell)
                tasks_and_results.append(" | ".join(processed_row))

            return tasks_and_results
        except Exception as e:
            print(f"Error reading from Google Sheets: {e}")
            return []

credentials_file = 'ML_Final.json'
sheet_id = '190B7MLVXzYf7b5dyZYUAvrLXlX6HydBi66i3wXqQ1jU'

sheets_handler = GoogleSheetsHandler(credentials_file, sheet_id)
tasks = sheets_handler.get_tasks(range_name='Sheet1!A1:C100')
print(tasks)
