from flask import Flask, request, jsonify, render_template
from GoogleSheetsHandler import GoogleSheetsHandler
from chatGPT_Integration import ChatGPTHandler

# Initialize Flask app
app = Flask(__name__)

# Configuration
credentials_file = 'ML_Final.json'
sheet_id = '190B7MLVXzYf7b5dyZYUAvrLXlX6HydBi66i3wXqQ1jU'
openai_api_key = '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' 

# Initialize handlers
sheets_handler = GoogleSheetsHandler(credentials_file, sheet_id)
chatgpt_handler = ChatGPTHandler(openai_api_key)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    user_query = request.json.get('query', '')  # Get user query from frontend

    # Fetch tasks from Google Sheets
    tasks = sheets_handler.get_tasks(range_name='Sheet1!A1:A10')
    if not tasks:
        tasks = ["No tasks found in Google Sheets."]

    # Prepare a prompt for ChatGPT
    prompt = f"""
    You are a task assistant. Here is the current list of tasks from Google Sheets:
    {', '.join(tasks)}.

    User's query: {user_query}
    Please respond appropriately using the above task list or provide an alternative answer.
    """

    # Get a response from ChatGPT
    response = chatgpt_handler.get_response(prompt)

    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)




from flask import Flask, request, jsonify, render_template
from GoogleSheetsHandler import GoogleSheetsHandler
from chatGPT_Integration import ChatGPTHandler
import ast

# Initialize Flask app
app = Flask(__name__)

# Configuration
credentials_file = 'ML_Final.json'
sheet_id = '190B7MLVXzYf7b5dyZYUAvrLXlX6HydBi66i3wXqQ1jU'
openai_api_key = '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' 

# Initialize handlers
sheets_handler = GoogleSheetsHandler(credentials_file, sheet_id)
chatgpt_handler = ChatGPTHandler(openai_api_key)

def evaluate_expression(expression):
    """Safely evaluate mathematical expressions."""
    try:
        # Evaluate only if it's a valid Python expression
        result = ast.literal_eval(expression)
        return result
    except (ValueError, SyntaxError):
        # If not evaluatable, return the expression as is
        return expression

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    user_query = request.json.get('query', '')  # Get user query from frontend

    # Fetch tasks from Google Sheets
    tasks = sheets_handler.get_tasks(range_name='Sheet1!A1:A10')
    processed_tasks = []

    # Process tasks: evaluate expressions if possible
    for task in tasks:
        if isinstance(task, str):  # Only process strings
            processed_tasks.append(f"{task} -> {evaluate_expression(task)}")
        else:
            processed_tasks.append(str(task))

    if not processed_tasks:
        processed_tasks = ["No tasks found in Google Sheets."]

    # Prepare a prompt for ChatGPT
    prompt = f"""
    You are a task assistant. Here is the current list of tasks from Google Sheets:
    {', '.join(processed_tasks)}.

    User's query: {user_query}
    Please respond appropriately using the above task list or provide an alternative answer.
    """

    # Get a response from ChatGPT
    response = chatgpt_handler.get_response(prompt)

    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)
